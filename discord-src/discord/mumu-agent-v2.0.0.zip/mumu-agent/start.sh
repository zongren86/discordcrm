#!/bin/bash
# MuMu Agent 启动脚本 (macOS/Linux)
# 安装依赖
if [ ! -d "node_modules" ]; then
    echo "[Agent] 安装依赖中..."
    npm install
fi
# 启动 Agent
node agent.js
