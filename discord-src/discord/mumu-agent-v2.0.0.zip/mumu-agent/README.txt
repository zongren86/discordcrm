========================================
  MuMu Agent v2.0.0 使用说明
========================================

## 文件说明
- agent.js - Agent 主程序
- config.json - 默认配置（macOS/merchantadmin）
- config_mac.json - macOS 平台配置
- config_win.json - Windows 平台配置
- package.json - Node.js 依赖配置

## 配置说明
Agent 启动时自动按以下优先级加载配置：
1. config.json（默认配置）
2. config_{平台}.json（平台特定配置，会覆盖默认）
   - macOS 加载 config_mac.json
   - Windows 加载 config_win.json

如需修改配置，直接编辑对应的 config 文件即可。

## 启动方式
### macOS/Linux:
    chmod +x start.sh
    ./start.sh

### Windows:
    双击 start.bat 或命令行执行:
    start.bat

## 或直接启动:
    node agent.js

## 依赖安装
首次运行需安装依赖：
    npm install

## 配置项说明
- userId: 商户账号ID（如 merchantadmin）
- merchantId: 商户ID
- serverUrl: WebSocket 服务地址
- mumuPath: MuMu 模拟器安装路径
- adbPath: ADB 工具路径（可选，自动查找）
- autoStart: 是否自动启动
