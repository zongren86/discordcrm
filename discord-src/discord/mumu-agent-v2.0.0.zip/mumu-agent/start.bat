@echo off
REM MuMu Agent 启动脚本 (Windows)
REM 安装依赖
if not exist "node_modules" (
    echo [Agent] 安装依赖中...
    call npm install
)
REM 启动 Agent
node agent.js
pause
